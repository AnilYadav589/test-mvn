package com.dolphinskart.healthcheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoHealthCheckAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
