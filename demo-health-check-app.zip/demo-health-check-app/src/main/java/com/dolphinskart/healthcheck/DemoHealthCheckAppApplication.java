package com.dolphinskart.healthcheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class DemoHealthCheckAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoHealthCheckAppApplication.class, args);
	}

	@RestController("/")
	class HealthCheck {
		@GetMapping("/")
		public String indexHealth() {
			return "indexHealth";
		}

		@GetMapping("health-check-application/")
		public String applicationHealth() {
			return "HealthCheckServiceApplication Healthy!!!";
		}
	}
}
